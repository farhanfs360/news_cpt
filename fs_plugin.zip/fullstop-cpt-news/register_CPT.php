<?php

/*

Plugin Name: Fullstop360 Register Post Types

Plugin URI: https://fullstop360.com/

Description: This plugin is created for Custom Post Type for News by Fullstop

Version: 1.0

Author: Farhan Khan

Author URI: https://fullstop360.com/

License: GPLv2 or later

Text Domain: Fullstop

*/

include( plugin_dir_path( __FILE__ ) . 'includes/news_cpt.php' );